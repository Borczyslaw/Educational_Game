package edu.psmw.projekt

import android.content.Context
import android.content.Intent
import android.media.Image
import android.os.Bundle
import android.os.StrictMode
import android.widget.ImageView
import androidx.appcompat.app.AppCompatActivity
import kotlinx.android.synthetic.main.activity_main.*
import kotlinx.android.synthetic.main.wybor_kategorii.*
import java.io.File
import java.util.*


class MainActivity : AppCompatActivity() {

    fun onClickTemp(word: Words, kat: String ): String
    {
        val rand_word = word.get_rand_word(this, "slowka/"+kat+".txt")
        return rand_word
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        StrictMode.allowThreadDiskReads()
        setContentView(R.layout.activity_main)
        btn_start_game.setOnClickListener{
            setContentView(R.layout.wybor_kategorii)
            val button_Ubr = btn_ubrania
            button_Ubr.setOnClickListener {
                val kat = "ubrania"
                val intent = Intent(this,GameActivity::class.java)
                intent.putExtra("kat", kat)
                startActivity(intent)
            }
            val button_dom = btn_dom
            button_dom.setOnClickListener {
                val kat = "dom"
                val intent = Intent(this,GameActivity::class.java)
                intent.putExtra("kat", kat)
                startActivity(intent)
            }
            val button_jedzenie = btn_jedzenie
            button_jedzenie.setOnClickListener {
                val kat = "jedzenie"
                val intent = Intent(this,GameActivity::class.java)
                intent.putExtra("kat", kat)
                startActivity(intent)
            }
            val button_szkola = btn_szkola
            button_szkola.setOnClickListener {
                val kat = "szkola"
                val intent = Intent(this,GameActivity::class.java)
                intent.putExtra("kat", kat)
                startActivity(intent)
            }
            val button_zwierzeta = zwierze
            button_zwierzeta.setOnClickListener {
                val kat = "Zwierzeta"
                val intent = Intent(this,GameActivity::class.java)
                intent.putExtra("kat", kat)
                startActivity(intent)

        }

        }

    }

}